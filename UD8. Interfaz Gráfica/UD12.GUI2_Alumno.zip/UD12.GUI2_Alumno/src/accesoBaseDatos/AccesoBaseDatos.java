package accesoBaseDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import modelo.Trabajador;

public class AccesoBaseDatos {

	public static boolean altaTrabajador(Trabajador t) {
		Connection conexion = null;
		try {
			conexion = config.ConfigBD.abrirConexion();
			String sentenciaInsertar = "INSERT INTO trabajadores(id,dni,nombre,apellidos,direccion,telefono,puesto) " + "VALUES (?,?,?,?,?,?,?)";
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaInsertar);
			// Dar valor a los ?
			sentencia.setInt(1, t.getIdentificador());
			sentencia.setString(2, t.getDni());
			sentencia.setString(3, t.getNombre());
			sentencia.setString(4, t.getApellidos());
			sentencia.setString(5, t.getDireccion());
			sentencia.setString(6, t.getTelefono());
			sentencia.setString(7, t.getPuesto());
			int filasInsertadas = sentencia.executeUpdate();

			if (filasInsertadas == 0) {
				return false;
			}
		} catch (SQLException sqle) {
			System.out.println("Error de SQL: " + sqle.getMessage());
			sqle.printStackTrace();
			return false;
		} finally {
			config.ConfigBD.cerrarConexion(conexion);
		}
		return true;
	}
	
	public static ArrayList<Trabajador> listarTrabajadores(){
		Connection conexion = null;
		ArrayList<Trabajador> listaTrabajadores = new ArrayList<Trabajador>();
		try {
			conexion = config.ConfigBD.abrirConexion();
			String sentenciaConsultar = "SELECT * FROM trabajadores ";
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaConsultar);
			ResultSet resultados = sentencia.executeQuery();
			while (resultados.next()) {
				Trabajador t = new Trabajador(
						resultados.getInt("id"),
						resultados.getString("dni"),
						resultados.getString("nombre"),
						resultados.getString("apellidos"),
						resultados.getString("direccion"),
						resultados.getString("telefono"),
						resultados.getString("puesto")
						);
				listaTrabajadores.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			config.ConfigBD.cerrarConexion(conexion);
		}
		return listaTrabajadores;
	}
	
	public static boolean bajaTrabajador(int id){
		Connection conexion = null;
		try {
			conexion = config.ConfigBD.abrirConexion();
			String sentenciaEliminar = "DELETE FROM trabajadores WHERE id = ? ";
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaEliminar);
			sentencia.setInt(1, id);
			int filasActualizadas = sentencia.executeUpdate();
			if (filasActualizadas == 0) {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			config.ConfigBD.cerrarConexion(conexion);
		}
		return true;
	}
	
	public static Trabajador buscarTrabajador(int id){
		Connection conexion = null;
		try {
			conexion = config.ConfigBD.abrirConexion();
			String sentenciaEliminar = "SELECT * FROM trabajadores WHERE id = ? ";
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaEliminar);
			sentencia.setInt(1, id);
			ResultSet resultados = sentencia.executeQuery();
			if(resultados.next()) {
				Trabajador t = new Trabajador(
						resultados.getInt("id"),
						resultados.getString("dni"),
						resultados.getString("nombre"),
						resultados.getString("apellidos"),
						resultados.getString("direccion"),
						resultados.getString("telefono"),
						resultados.getString("puesto")
						
						);
				return t;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			config.ConfigBD.cerrarConexion(conexion);
		}
		return null;
	}
	
	public static boolean modificarTrabajador(Trabajador t){
		Connection conexion = null;
		try {
			conexion = config.ConfigBD.abrirConexion();
			String sentenciaModificar = "UPDATE trabajadores SET dni = ?, nombre = ?, apellidos = ?, direccion = ?, telefono = ?, puesto = ? WHERE id = ? ";
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaModificar);
			sentencia.setString(1, t.getDni());
			sentencia.setString(2, t.getNombre());
			sentencia.setString(3, t.getApellidos());
			sentencia.setString(4, t.getDireccion());
			sentencia.setString(5, t.getTelefono());
			sentencia.setString(6, t.getPuesto());
			sentencia.setInt(7, t.getIdentificador());
			int filasActualizadas = sentencia.executeUpdate();
			if (filasActualizadas == 0) {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			config.ConfigBD.cerrarConexion(conexion);
		}
		return true;
	}
	
}
