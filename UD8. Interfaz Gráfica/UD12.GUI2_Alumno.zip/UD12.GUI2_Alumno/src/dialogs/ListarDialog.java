/**
 * 
 */
package dialogs;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import accesoBaseDatos.AccesoBaseDatos;
import modelo.Empresa;
import modelo.Trabajador;

/**
 * 
 * @author usuario
 *
 */
public class ListarDialog extends JDialog implements ActionListener {

	JTable tabla;
	JButton cerrar;
	JButton ExportarCSV;

	public ListarDialog() {

		setResizable(false);
		// t�tulo del di�log
		setTitle("Listado Trabajadores");
		// tama�o
		setSize(750, 700);
		setLayout(new FlowLayout());
		// colocaci�n en el centro de la pantalla
		setLocationRelativeTo(null);

		// Crea un JTable, cada fila será un trabajador
		String[] columnas = { "Identificador", "DNI", "Nombre", "Apellidos", "Direcci�n", "Tel�fono", "Puesto" };
		// Crea un JTable, cada fila será un trabajador
		ArrayList<Trabajador> trabajadores = AccesoBaseDatos.listarTrabajadores();

		// Crear una matriz para almacenar los datos
		String[][] datos = new String[trabajadores.size()][columnas.length];

		// Llenar la matriz con los datos de los trabajadores
		for (int i = 0; i < trabajadores.size(); i++) {
			Trabajador trabajador = trabajadores.get(i);
			datos[i][0] = String.valueOf(trabajador.getIdentificador());
			datos[i][1] = trabajador.getDni();
			datos[i][2] = trabajador.getNombre();
			datos[i][3] = trabajador.getApellidos();
			datos[i][4] = trabajador.getDireccion();
			datos[i][5] = trabajador.getTelefono();
			datos[i][6] = trabajador.getPuesto();
		}
		tabla = new JTable(datos, columnas);
		// Mete la tabla en un JCrollPane
		JScrollPane jsp = new JScrollPane(tabla);
		jsp.setPreferredSize(new Dimension(700, 600));
		add(jsp);

		cerrar = new JButton("Cerrar");
		cerrar.addActionListener(this);
		add(cerrar);
		
		ExportarCSV = new JButton("ExportarCSV");
		ExportarCSV.addActionListener(this);
		add(ExportarCSV);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cerrar) {
            dispose();
        } else if (e.getSource() == ExportarCSV) {
            exportarCSV();
        }
    }
	
	public static void exportarCSV() {
		BufferedWriter bw = null;
		ArrayList<Trabajador> listaTrab = AccesoBaseDatos.listarTrabajadores();
		File fichero = new File("ficheroDatos/ficheroCSV.txt");
		FileWriter fw;
		try {
			fw = new FileWriter(fichero,false);
			bw = new BufferedWriter(fw);
			
			for (Trabajador t : listaTrab) {
				bw.write(t.toStringWithSeparators());
				bw.newLine();
			}
			bw.close();
				
			
		} catch (IOException e) {
			System.out.println("Error al leer del fichero"+ e.getMessage());
			e.printStackTrace();
		} 
		finally {
			// Cierra el fichero
			try {
				if (bw != null) {					
					bw.close();
				} 
			}
			catch (IOException e) {
				System.out.println("Error al cerrar el fichero: " + e.getMessage());
				e.printStackTrace();
			}
		}	
	}
}
