package dialogs;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import accesoBaseDatos.AccesoBaseDatos;
import modelo.Empresa;
import modelo.Trabajador;

public class BuscarDialog extends JDialog implements ActionListener{
	
	JLabel etiquetaIdentificador;
	JTextField areaIdentificador;
	JLabel texto;
	JTextArea informacionTrabajadores;

	
	JButton identificador;
	JButton aceptar;
	JButton cancelar;
	
	JTable tabla;
	
	JPanel pIdentificador;
	JPanel pInformacion;
	JPanel pBotones;
		
	public BuscarDialog() {
		
		setResizable(false);
		setTitle("Buscar Trabajador");
		setSize(300, 350);
		setLayout(new FlowLayout());
		setLocationRelativeTo(null);
		
		texto = new JLabel("<html>Introduzca el ID del trabajador<br> que desea listar<br><br></html>");
		add(texto);
		
		pIdentificador = new JPanel();
		pInformacion = new JPanel();
		pBotones = new JPanel();
		
		// Añadir al JDialog los JPanel
		add(pIdentificador);
		add(pInformacion);
		add(pBotones);
		
		etiquetaIdentificador = new JLabel("Identificador");
		areaIdentificador = new JTextField(15);
		pIdentificador.add(etiquetaIdentificador);
		pIdentificador.add(areaIdentificador);
		
		informacionTrabajadores = new JTextArea();
		informacionTrabajadores.setEditable(false);
		Color defaultBackgroundColor = pInformacion.getBackground();
		informacionTrabajadores.setBackground(defaultBackgroundColor);
		pInformacion.add(informacionTrabajadores);

		
		aceptar = new JButton("Aceptar");
		aceptar.addActionListener(this);
		pBotones.add(aceptar);

		cancelar = new JButton("Cancelar");
		cancelar.addActionListener(this);
		pBotones.add(cancelar);
		
		// Visible
		setVisible(true);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		

		
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == aceptar) {
				Trabajador trabajador = AccesoBaseDatos.buscarTrabajador(Integer.parseInt(areaIdentificador.getText()));
				if (trabajador != null) {
					informacionTrabajadores.setText(trabajador.toString());
				} else {
					JOptionPane.showMessageDialog(null, "El trabajador no se encuentra en la lista", "Error",
							JOptionPane.ERROR_MESSAGE);
				}

		} else if (e.getSource() == cancelar) {
			dispose();
		}
	}

}
