	/**
	 * 
	 */
	package modelo;
	
	/**
	 * @author alumno
	 *
	 */
	public class Trabajador  { //implements Serializable 
		
		private int identificador;
		private String dni;
		private String nombre;
		private String apellidos;
		private String direccion;
		private String telefono;
		private String puesto;
		
		private static final String SEPARADOR = ";";
		/**
		 * @param identificador
		 * @param dni
		 * @param nombre
		 * @param apellidos
		 * @param direccion
		 * @param telefono
		 * @param puesto
		 */
		public Trabajador(int identificador, String dni, String nombre,
				String apellidos, String direccion, String telefono, String puesto) {
			this.identificador = identificador;
			this.dni = dni;
			this.nombre = nombre;
			this.apellidos = apellidos;
			this.direccion = direccion;
			this.telefono = telefono;
			this.puesto = puesto;
		}
		
		public Trabajador(String linea) {
			String[] datos = linea.split(SEPARADOR);
			this.identificador = Integer.parseInt(datos[0]);
			this.dni = datos[1];
			this.nombre = datos[2];
			this.apellidos = datos[3];
			this.direccion = datos[4];
			this.telefono = datos[5];
			this.puesto = datos[6];
		}
		/**
		 * @return the identificador
		 */
		public int getIdentificador() {
			return identificador;
		}
		/**
		 * @param identificador the identificador to set
		 */
		public void setIdentificador(int identificador) {
			this.identificador = identificador;
		}
		/**
		 * @return the dni
		 */
		public String getDni() {
			return dni;
		}
		/**
		 * @param dni the dni to set
		 */
		public void setDni(String dni) {
			this.dni = dni;
		}
		/**
		 * @return the nombre
		 */
		public String getNombre() {
			return nombre;
		}
		/**
		 * @param nombre the nombre to set
		 */
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		/**
		 * @return the apellidos
		 */
		public String getApellidos() {
			return apellidos;
		}
		/**
		 * @param apellidos the apellidos to set
		 */
		public void setApellidos(String apellidos) {
			this.apellidos = apellidos;
		}
		/**
		 * @return the direccion
		 */
		public String getDireccion() {
			return direccion;
		}
		/**
		 * @param direccion the direccion to set
		 */
		public void setDireccion(String direccion) {
			this.direccion = direccion;
		}
		/**
		 * @return the telefono
		 */
		public String getTelefono() {
			return telefono;
		}
		/**
		 * @param telefono the telefono to set
		 */
		public void setTelefono(String telefono) {
			this.telefono = telefono;
		}
		/**
		 * @return the puesto
		 */
		public String getPuesto() {
			return puesto;
		}
		/**
		 * @param puesto the puesto to set
		 */
		public void setPuesto(String puesto) {
			this.puesto = puesto;
		}
		@Override
		public String toString() {
			return "id=" + identificador + "\n" + "DNI:" + dni + "\n" + "Nombre:" + nombre + "\n" + "Apellidos:"
					+ apellidos + "\n" + "Dirección:" + direccion + "\n" + "Teléfono:" + telefono + "\n" + "Puesto:" + puesto;
		}
		
		public String toStringWithSeparators() {
			return 
				this.identificador + SEPARADOR + 
				this.dni + SEPARADOR + 
				this.nombre + SEPARADOR +
				this.apellidos + SEPARADOR +
				this.direccion + SEPARADOR +
				this.telefono + SEPARADOR +
				this.puesto + SEPARADOR;
		}		
	}