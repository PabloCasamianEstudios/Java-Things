package ficheros;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import accesoBaseDatos.AccesoBaseDatos;
import modelo.Trabajador;

/**
 * @author alumno
 *
 */
public class FicheroDatos {
	//PASAR A LA BASE DE DATOS EL ESCRIBIR TRABAJADORES
	/**
	 * Escribe un ArrayList en el fichero
	 * @param ruta
	 * @param trabajadores
	 */
	public static void escribirTrabajadores(String ruta, ArrayList<Trabajador> trabajadores){
		
		DataOutputStream fichero = null;
		try {
			fichero = new DataOutputStream (new FileOutputStream(ruta)); 
			for(int i=0; i<trabajadores.size(); i++){
				fichero.writeInt(trabajadores.get(i).getIdentificador());
				fichero.writeUTF(trabajadores.get(i).getDni());
				fichero.writeUTF(trabajadores.get(i).getNombre());
				fichero.writeUTF(trabajadores.get(i).getApellidos());
				fichero.writeUTF(trabajadores.get(i).getDireccion());
				fichero.writeUTF(trabajadores.get(i).getTelefono());
				fichero.writeUTF(trabajadores.get(i).getPuesto());
			}		
		} 
		catch (FileNotFoundException e1){
			System.out.printf("Error al abrir fichero para escritura");
		}
		catch (IOException e){ 
			System.out.printf("Error al escribir en el fichero%n"); 
		} 
		finally{ 
			try{
			fichero.close();
			} 
			catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		}		
	}
	
	/**
	 * Devuelve un arraylist con los trabajadores del fichero
	 * @param rutaFichero
	 * @return
	 */
	public static void obtenerTrabajadores(String rutaFichero) {

		Connection conexion = null;
		DataInputStream ficheroDatos=null;
		try {
			conexion = config.ConfigBD.abrirConexion();
			ficheroDatos=new DataInputStream(new FileInputStream(rutaFichero));
			while (true){
				int id = ficheroDatos.readInt();
				String dni =ficheroDatos.readUTF();
				String nombre =ficheroDatos.readUTF();
				String apellidos =ficheroDatos.readUTF();
				String direccion =ficheroDatos.readUTF();
				String telefono =ficheroDatos.readUTF();
				String puesto =ficheroDatos.readUTF();
				String sentenciaInsertar = "INSERT INTO trabajadores(id,dni,nombre,apellidos,direccion,telefono,puesto) VALUES (?,?,?,?,?,?,?) "
						+ "ON CONFLICT(id) DO UPDATE SET dni = excluded.dni, nombre = excluded.nombre, apellidos = excluded.apellidos, direccion = excluded.direccion, telefono = excluded.telefono, puesto = excluded.puesto";
				PreparedStatement sentencia = conexion.prepareStatement(sentenciaInsertar);
				sentencia.setInt(1, id);
				sentencia.setString(2, dni);
				sentencia.setString(3, nombre);
				sentencia.setString(4, apellidos);
				sentencia.setString(5, direccion);
				sentencia.setString(6, telefono);
				sentencia.setString(7, puesto);
				sentencia.executeUpdate();	
			}
			
		}
		catch (EOFException e){
			
		} 
		catch (FileNotFoundException e){
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				ficheroDatos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
	}

}
